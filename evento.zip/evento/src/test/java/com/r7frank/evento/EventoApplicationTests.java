package com.r7frank.evento;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EventoApplicationTests {

	@Test
	void contextLoads() {
	}

}
